/*
Austin Duda
Info-308
Homework 5
Feburary 12th 2018
*/

#include <iostream>
#include <string>
using namespace std;

class node
{
public:
	int account_number;
	string name;
	double balance;
	node * next;
public:
	node(int v, string n, double b);
};

node::node(int v, string n, double b)
{
	this->account_number = v;
	this->name = n;
	this->balance = b;
	this->next = NULL;
}



//instert new classes to sort in increasing, decreasing and delete lists.
class Account_List
{
private:
	node * head;

public:
	Account_List();
	~Account_List();
	void insert_to_head(int v, string n, double b);
	void insert_in_order_account(int v, string n, double b);
	void insert_in_order_balance(int v, string n, double b);
	void list_all();
	bool search(string name);
};

void insert_in_order_account(int v, string n, double b) {
	node* newnode;
	node* head;
	if (head == NULL) {
		head = newnode;
		return;
	}
	if (head->account_number >= newnode->account_number) {
		newnode->next = head;
		head = newnode;
		return;
	}
	else {
		node* t1 = head;
		node*t2 = t1->next;

		while (t2 != NULL) {
			if (t2->account_number < newnode->account_number) {
				t1 = t2;
				t2 = t1->next;
			}
			else
				newnode->next = t2;
			t1->next = newnode;
			return;
		}
		t1->next = newnode;
	}
}


Account_List::Account_List()
{
	head = NULL;
}

Account_List::~Account_List()
{
	while (head != NULL)
	{
		node * temp = head;
		head = head->next;
		delete temp;
	}
}

void Account_List::insert_to_head(int v, string n, double b)
{
	node * temp = new node(v, n, b);

	temp->next = head;
	head = temp;
}

void Account_List::list_all()
{
	node * temp = head;
	while (temp != NULL)
	{
		cout << temp->account_number << "\t" << temp->name << "\t" << temp->balance << endl;
		temp = temp->next;
	}
}

bool Account_List::search(string name)
{
	node * temp = head;
	while (temp != NULL)
	{
		if (temp->name.compare(name) == 0) return true;
		else temp = temp->next;
	}
	return false;
}

int main()
{
	Account_List List;
	List.insert_in_order_account(2002, "Janet Smith", 100.99);
	List.insert_in_order_account(1001, "Alex Bush", 99.88);
	List.insert_in_order_account(3003, "John Rosa", 5.55);
	cout << "List is in increasing order of account number\n";
	List.list_all();
	cout << endl;
	//List.remove("Janet Smith");
//	List.remove("Alex Bush");
	cout << "Two nodes are removed\n";
	List.list_all();
	cout << endl;
	List.insert_in_order_balance(2002, "Janet Smith", 100.99);
	List.insert_in_order_balance(1001, "Alex Bush", 99.88);
	cout << "List is in decreasing order of balance\n";
	List.list_all();
	cout << endl;
	//List.insertion_sort_by_account();
	cout << "List is in increasing order of account number\n";
	List.list_all();
	cout << endl;
	cin.get();
	return 1;
}
