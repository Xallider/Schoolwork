/*
Austin Duda
Info-308
Homework 6 list
Feburary 26th 2018
*/

#include <iostream>
#include <string>
using namespace std;

class node
{
public:
	int account_number;
	string name;
	double balance;
	node * next;
public:
	node(int v, string n, double b);
};

node::node(int v, string n, double b)
{
	this->account_number = v;
	this->name = n;
	this->balance = b;
	this->next = NULL;
}

class Account_Stack
{
private:
	node * top;

public:
	Account_Stack();
	~Account_Stack();
	bool isEmpty();
	void push(node * n);
	node * pop();
};

Account_Stack::Account_Stack()
{
	top = NULL;
}

Account_Stack::~Account_Stack()
{
	node * temp = top;
	while (top != NULL)
	{
		top = top->next;
		delete temp;
		temp = top;
	}
}

bool Account_Stack::isEmpty()
{
	if (top == NULL) return true;
	else return false;
}

void Account_Stack::push(node * n)
{
	// your code goes here
	// push n into the stack
	n->next = top;
	top = n;

}

node * Account_Stack::pop()
{
	if (isEmpty() == false)
	{
		// your code goes here
		// pop (and return) the top node out of the stack

		node * ttm = top;
		top = top->next;
		return ttm;
		delete ttm;
	}
	else return NULL;
}

int main()
{
	Account_Stack instac;

	node * n1 = new node(2002, "Janet Smith", 100.99);
	node * n2 = new node(1001, "Alex Bush", 99.88);
	node * n3 = new node(3003, "John Rosa", 5.55);

	instac.push(n1);
	instac.push(n2);
	instac.push(n3);

	node * temp = instac.pop();

	while (temp != NULL)
	{
		cout << temp->name << endl;
		temp = instac.pop();
	}
	cin.get();
	return 1;
}

/*
// after a successful implementation, running this program
// the following result will be shown
John Rosa
Alex Bush
Janet Smith
*/

