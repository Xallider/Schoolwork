/*
Austin Duda
Info-308
Homework 7 array
Feburary 26th 2018
*/
#include <iostream>
#include <string>
using namespace std;

class node
{
public:
	int account_number;
	string name;
	double balance;
public:
	node(int v, string n, double b);
};

node::node(int v, string n, double b)
{
	this->account_number = v;
	this->name = n;
	this->balance = b;
}

class Account_Queue
{
private:
	node ** myqueue;
	int size;
	int head;
	int tail;
	int current_size;

public:
	Account_Queue(int size);
	~Account_Queue();
	bool isFull();
	bool isEmpty();
	void enqueue(node * n);
	node * dequeue();
};

Account_Queue::Account_Queue(int size)
{
	// your code goes here
	// allocate space for array (myqueue)
	
	int *myqueue= new int[size];
	this->size = size;
	head = 0;
	tail = 0;
	current_size = 0;
	
}

Account_Queue::~Account_Queue()
{
	delete[] myqueue;
}

bool Account_Queue::isFull()
{
	if (current_size == size) return true;
	else return false;
}

bool Account_Queue::isEmpty()
{
	if (current_size == 0) return true;
	else return false;
}

void Account_Queue::enqueue(node * n)
{
	if (isFull() == false)
	{
		
		// your code goes here
		// insert node n to the back (rear) of the queue
		myqueue[tail] = n;	//causing break exception
		if (tail == size - 1) tail = 0;
		else tail = tail + 1;
		current_size++;

	}
}

node * Account_Queue::dequeue()
{
	if (isEmpty() == false)
	{
		// your code goes here
		// remove(and return) the node in front of the queue
		node* temp = myqueue[head];
		if (head == size - 1) head = 0;
		else head = head + 1;
		current_size--;
		return temp;

	}
	else return NULL;
}

int main()
{
	Account_Queue inque(50);
	node * n1 = new node(2002, "Janet Smith", 100.99);
	node * n2 = new node(1001, "Alex Bush", 99.88);
	node * n3 = new node(3003, "John Rosa", 5.55);

	inque.enqueue(n1);
	inque.enqueue(n2);
	inque.enqueue(n3);

	node * t1 = inque.dequeue();
	while (t1 != NULL)
	{
		cout << t1->name << endl;
		delete t1;
		t1 = inque.dequeue();
	}
	cin.get();

	return 1;
}

/*
// after a successful implementation, running this program
// the following result will be shown
Janet Smith
Alex Bush
John Rosa
*/