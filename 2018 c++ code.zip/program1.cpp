#include <iostream>
#include <string>
using namespace std;

int getPrime(int);
int hash_code_map(int act, string name);

class node
{
public:
	int account_number;
	string name;
	double balance;
	node * next;
public:
	node(int v, string n, double b);
};

node::node(int v, string n, double b)
{
	this->account_number = v;
	this->name = n;
	this->balance = b;
	this->next = NULL;
}

class hashtable
{
public:
	node ** array;
	int size;
public:
	hashtable(int n);
	void insert(int act, string n, double b);
	void remove(int act, string name);
	node * search(int act, string name);
};

hashtable::hashtable(int n)
{
	// your code goes here
	// (1) determine the array size;
	// (2) allocate space for array
	// (3) set each cell in the array point to NULL
	int N = getPrime(n);
	size = N;
	array = new node*[size];      //needs N to be found by Get Prime

	for (int i = 0; i < size; i++)
	{
		array[i] = NULL;
	}
}

void hashtable::insert(int act, string n, double b)
{
	// your code goes here
	// create a node and insert it to the hashtable
	int key = hash_code_map(act, n);
	int index = key % size;
	node * entry = new node(act, n, b);
	if (array[index] == NULL)
	{
		array[index] = entry;
	}
	else if (array[index] != NULL)
	{
		while (array[index]->next != NULL)
			array[index] = array[index]->next;
		array[index]->next = entry;
	}
}

void hashtable::remove(int act, string n)
{
	// your code goes here
	// find the node and delete it.
	// do nothing if it can not be found
	int key = hash_code_map(act, n);
	int index = key % size;
	if (array[index] != NULL)
	{
		if (array[index]->account_number == act && array[index]->name == n)
			array[index] = NULL;
		else
		{
			while (array[index]->next != NULL)
			{
				array[index] = array[index]->next;
				if (array[index]->account_number == act && array[index]->name == n)
					array[index] = NULL;
			}
		}
	}
}


node * hashtable::search(int act, string name)
{
	// your code goes here
	// find the node and return it (the pointer).
	// retun NULL if it can not be found
	int key = hash_code_map(act, name);
	int index = key % (this->size);
	if (array[index] != NULL)
	{
		if (array[index]->account_number == act && array[index]->name == name)
			return (array[index]);
		else
		{
			while (array[index]->next != NULL)
			{
				array[index] = array[index]->next;
				if (array[index]->account_number == act && array[index]->name == name)
					return (array[index]);
			}
		}
	}
	return NULL;
}


int getPrime(int n)
{
	// your code goes here
	// return the smallest prime number that is greater than n
	// suppose n>=2
	int i, j;
	bool isPrime = false;
	for (i = n + 1; isPrime == true; i++)
	{
		isPrime = true;
		for (j = 2; j <= i / 2; j++)
		{
			if (j % i == 0)
				isPrime = false;
		}
	}
	return i;
}


int hash_code_map(int act, string name)
{
	// your code goes here
	// map(convert) account number (act) and name into an integer
	// act + summation of the ASCII values of each character in the string
	int key, j, nameASCII;
	char c;
	nameASCII = 0;
	for (size_t i = 0; i < name.length(); i++)
	{
		c = name[i];
		j = (int)c;
		nameASCII = nameASCII + j;
	}
	key = act + nameASCII;
	return key;
}

int main()
{
	hashtable ht(100);
	ht.insert(2002, "Janet Smith", 100.99);
	ht.insert(1001, "Alex Bush", 99.88);
	ht.insert(3003, "John Rosa", 5.55);

	node * n;
	n = ht.search(1001, "Alex Bush");

	if (n != NULL) cout << "the balance of account 1001 is " << n->balance << endl;
	else cout << "could not find account 1001";

	ht.remove(1001, "Alex Bush");

	n = ht.search(1001, "Alex Bush");
	if (n != NULL) cout << "the balance of account 1001 is " << n->balance << endl;
	else cout << "could not find account 1001" << endl;

	cin.get();
	return 1;
}
/*
// if your hashtable is corrected implemented,
// you should see the following result:

the balance of account 1001 is 99.88
could not find account 1001

*/

