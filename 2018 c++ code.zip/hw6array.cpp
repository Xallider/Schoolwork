/*
Austin Duda
Info-308
Homework 6 array
Feburary 26th 2018
*/

#include <iostream>
#include <string>
using namespace std;

class node
{
public:
	int account_number;
	string name;
	double balance;
public:
	node(int v, string n, double b);
};

node::node(int v, string n, double b)
{
	this->account_number = v;
	this->name = n;
	this->balance = b;
}

class Account_Stack
{
private:
	node ** mystack; //mystack is an array of pointers to node
	int *mystack;
	int size;
	int current_index;

public:
	Account_Stack(int size);
	~Account_Stack();
	bool isFull();
	bool isEmpty();
	void push(node * n);
	node * pop();
};

Account_Stack::Account_Stack(int size)
{
	//your code goes here
	//allocate space for array mystack, which is an array of pointers (to node)
	mystack = new int[size];
	this->size = size;
	current_index = 0;
}

Account_Stack::~Account_Stack()
{
	delete[] mystack;
}

bool Account_Stack::isFull()
{
	if (current_index == size) return true;
	else return false;
}

bool Account_Stack::isEmpty()
{
	if (current_index == 0) return true;
	else return false;
}

void Account_Stack::push(node * n)
{
	if (isFull() == false)
	{
		mystack[current_index] = n;
		current_index = current_index + 1;
		// your code goes here
		// push n into the stack
	}
}

node * Account_Stack::pop()
{
	if (isEmpty() == false)
	{
		// your code goes here
		// pop (and return) the top node out of the stack
		current_index = current_index - 1;
		return mystack[current_index];
	}
	else return NULL;
}

int main()
{
	Account_Stack instac(50);

	node * n1 = new node(2002, "Janet Smith", 100.99);
	node * n2 = new node(1001, "Alex Bush", 99.88);
	node * n3 = new node(3003, "John Rosa", 5.55);

	instac.push(n1);
	instac.push(n2);
	instac.push(n3);
	cout << instac.pop()->name << endl;
	cout << instac.pop()->name << endl;
	cout << instac.pop()->name << endl;
	cin.get();
	return 1;
}

/*
// after a successful implementation, running this program
// the following result will be shown
John Rosa
Alex Bush
Janet Smith
*/