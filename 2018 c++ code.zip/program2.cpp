
#include <iostream>
#include <string>
using namespace std;

int getPrime(int);
int hash_code_map(int act);

class BinaryNode
{
public:
	int account_number;
	string name;
	double balance;
	BinaryNode * left;
	BinaryNode * right;
public:
	BinaryNode(int account_number, string name, double balance);
};

BinaryNode::BinaryNode(int account_number, string name, double balance)
{
	this->account_number = account_number;
	this->name = name;
	this->balance = balance;
	this->left = NULL;
	this->right = NULL;
}

class hashtable
{
public:
	BinaryNode ** array;
	int size;
public:
	hashtable(int n);
	void insert(int act, string n, double b);
	void remove(int act, string name);
	BinaryNode * search(int act, string name);
};

hashtable::hashtable(int n)
{
	int N = getPrime(n);
	size = N;
	array = new BinaryNode*[size];

	for (int i = 0; i < size; i++)
	{
		array[i] = NULL;
	}
}

void hashtable::insert(int act, string n, double b)
{
	int key = hash_code_map(act);
	int index = key % size;
	BinaryNode * entry = new BinaryNode(act, n, b);
	if (array[index] == NULL)
	{
		array[index] = entry;
	}
	else if (array[index] != NULL && entry->account_number < array[index]->account_number)
	{
		while (array[index]->left != NULL)
			array[index] = array[index]->left;
		array[index]->left = entry;
	}
	else if (array[index] != NULL && entry->account_number > array[index]->account_number)
	{
		while (array[index]->right != NULL)
			array[index] = array[index]->right;
		array[index]->right = entry;
	}
}

void hashtable::remove(int act, string n)
{
	int key = hash_code_map(act);
	int index = key % size;
	if (array[index] != NULL)
	{
		if (array[index]->account_number == act && array[index]->name == n)
			array[index] = NULL;
		else
		{
			while (array[index]->left != NULL)
			{
				array[index] = array[index]->left;
				if (array[index]->account_number == act && array[index]->name == n)
					array[index] = NULL;
			}
			while (array[index]->right != NULL)
			{
				array[index] = array[index]->right;
				if (array[index]->account_number == act && array[index]->name == n)
					array[index] = NULL;
			}
		}
	}
}

BinaryNode * hashtable::search(int act, string name)
{
	int key = hash_code_map(act);
	int index = key % size;
	if (array[index] != NULL)
	{
		if (array[index]->account_number == act && array[index]->name == name)
			return (array[index]);
		else
		{
			while (array[index]->left != NULL)
			{
				array[index] = array[index]->left;
				if (array[index]->account_number == act && array[index]->name == name)
					return (array[index]);
			}
			while (array[index]->right != NULL)
			{
				array[index] = array[index]->right;
				if (array[index]->account_number == act && array[index]->name == name)
					return (array[index]);
			}
		}
	}
	return NULL;
}


int getPrime(int n)
{
	int i, j;
	bool isPrime = false;
	for (i = n + 1; isPrime == true; i++)
	{
		isPrime = true;
		for (j = 2; j <= i / 2; j++)
		{
			if (j % i == 0)
				isPrime = false;
		}
	}
	return i;
}


int hash_code_map(int act)
{
	return act;
}

int main()
{
	hashtable ht(100);
	ht.insert(2002, "Janet Smith", 100.99);
	ht.insert(1001, "Alex Bush", 99.88);
	ht.insert(3003, "John Rosa", 5.55);

	BinaryNode * n;
	n = ht.search(1001, "Alex Bush");

	if (n != NULL) cout << "the balance of account 1001 is " << n->balance << endl;
	else cout << "could not find account 1001";

	ht.remove(1001, "Alex Bush");

	n = ht.search(1001, "Alex Bush");
	if (n != NULL) cout << "the balance of account 1001 is " << n->balance << endl;
	else cout << "could not find account 1001" << endl;
	cin.get();
	return 1;
}