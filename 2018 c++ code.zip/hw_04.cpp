/*
Austin Duda
Info-308
Homework 4
Feburary 12th 2018
*/
#include <iostream>
#include <string>
#include <stdlib.h>
using namespace std;

class node
{
public:
	int value;
	string name;
	double balance;
	int accnumber;
	node * next;
public:
	node(int v, string n, double b);
};



node::node(int v, string n, double b)
{
	this->value = value;
	this->balance = balance;
	this->name = name;
	this->accnumber = accnumber;
	this->next = NULL;
}



//integer list previously
class Account_List
{
private:
	node * head;

public:
	Account_List();
	~Account_List();
	void insert_to_head(int v, string n, double b);
	void list_all();
	bool search(string n);
};

//constructor
Account_List::Account_List()
{
	head = NULL;
}
//deconstructor
Account_List::~Account_List()
{
	while (head != NULL)
	{
		node * temp = head;
		head = head->next;
		delete temp;
	}
}

//new node takes 3 values and sets the values entered to those in node's class
void Account_List::insert_to_head(int v, string n, double b)
{
	node * temp = new node(v, n, b);
	temp->accnumber = v;
	temp->name = n;
	temp->balance = b;

	temp->next = head;
	head = temp;
}

//prints out stored information in the nodes.
void Account_List::list_all()
{
	node * temp = head;
	while (temp != NULL)
	{
		cout << temp->accnumber << " ";
		cout << temp->name << " ";
		cout << temp->balance << endl;
		temp = temp->next;
	}
}

//searches the list for string stored in nodes entered in the main.
bool Account_List::search(string n)
{
	node * temp = head;
	string name = temp->name;
	while (temp != NULL)
	{

		if (temp->name.compare(n) == 0) {
			return true;
		}
		else temp = temp->next;
	}
	return false;
}

int main()
{
	Account_List List;
	List.insert_to_head(2002, "Janet Smith", 100.99);
	List.insert_to_head(1001, "Alex Bush", 99.88);
	List.insert_to_head(3003, "John Rosa", 5.55);
	List.list_all();
	if (List.search("Alex Bush") == true) cout << "Found Alex\n";
	else cout << "Cound not find Alex\n";
	if (List.search("Bush Alex") == true) cout << "Found Bush\n";
	else cout << "Could not find Bush\n";
	//pause system console.
	cin.get();
	return 1;


}