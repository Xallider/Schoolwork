/*
Austin Duda
Hw05
2/19/2018
*/

#include <iostream>
#include <string>
using namespace std;

class node
{
public:
	int account_number;
	string name;
	double balance;
	node * next;
public:
	node(int v, string n, double b);
};

node::node(int v, string n, double b)
{
	this->account_number = v;
	this->name = n;
	this->balance = b;
	this->next = NULL;
}

class Account_List
{
private:
	node * head;

public:
	Account_List();
	~Account_List();
	void insert_to_head(int v, string n, double b);
	void list_all();
	bool search(string name);
	void insert_in_order_account(int v, string n, double b);
	void insert_in_order_balance(int v, string n, double b);
	void remove(string name);
	void insertion_sort_by_account();
};

Account_List::Account_List()
{
	head = NULL;
}

Account_List::~Account_List()
{
	while (head != NULL)
	{
		node * temp = head;
		head = head->next;
		delete temp;
	}
}

void Account_List::insert_to_head(int v, string n, double b)
{
	node * temp = new node(v, n, b);

	temp->next = head;
	head = temp;
}

void Account_List::list_all()
{
	node * temp = head;
	while (temp != NULL)
	{
		cout << temp->account_number << "\t" << temp->name << "\t" << temp->balance << endl;
		temp = temp->next;
	}
}

bool Account_List::search(string name)
{
	node * temp = head;
	while (temp != NULL)
	{
		if (temp->name.compare(name) == 0) return true;
		else temp = temp->next;
	}
	return false;
}


//increasing order
void Account_List::insert_in_order_account(int v, string n, double b)
{
	node * temp = new node(v, n, b);
	if (head == NULL)
		head = temp;
	else if (temp->account_number <= head->account_number)
	{
		temp->next = head;
		head = temp;
	}
	else
	{
		node * t1 = head;
		node * t2 = head->next;
		while (t2 != NULL && temp->account_number > t2->account_number)
		{
			t1 = t2;
			t2 = t2->next;
		}
		temp->next = t2;
		t1->next = temp;
	}
}

void Account_List::insert_in_order_balance(int v, string n, double b)
{
	node * temp = new node(v, n, b);
	if (head == NULL)
		head = temp;
	else if (temp->balance >= head->balance)
	{
		temp->next = head;
		head = temp;
	}
	else
	{
		node * t1 = head;
		node * t2 = head->next;
		while (t2 != NULL && temp->balance < t2->balance)
		{
			t1 = t2;
			t2 = t2->next;
		}
		temp->next = t2;
		t1->next = temp;
	}

}

void Account_List::remove(string name)
{
	while (head != NULL && head->name == name)
	{
		node * temp = head;
		head = head->next;
		delete temp;
	}
	if (head == NULL)
		return;
	else
	{
		node * t1 = head;
		node * t2 = head->next;
		while (t2 != NULL)
		{
			if (t2->name == name)
			{
				node * temp = t2;
				t2 = t2->next;
				t1->next = t2;
				delete temp;
			}
			else
			{
				t1 = t2;
				t2 = t2->next;
			}
		}
	}
}

void Account_List::insertion_sort_by_account()
{
	int v = head->account_number;
	string n = head->name;
	double b = head->balance;
	node * temp2 = new node(v, n, b);
	if (head == NULL)
		head = temp2;
	else if (temp2->account_number <= head->account_number)
	{
		temp2->next = head;
		head = temp2;
	}
	
}

int main()
{
	Account_List List;
	List.insert_in_order_account(2002, "Janet Smith", 100.99);
	List.insert_in_order_account(1001, "Alex Bush", 99.88);
	List.insert_in_order_account(3003, "John Rosa", 5.55);
	cout << "List is in increasing order of account number\n";
	List.list_all();
	cout << endl;
	List.remove("Janet Smith");
	List.remove("Alex Bush");
	cout << "Two nodes are removed\n";
	List.list_all();
	cout << endl;
	List.insert_in_order_balance(2002, "Janet Smith", 100.99);
	List.insert_in_order_balance(1001, "Alex Bush", 99.88);
	cout << "List is in decreasing order of balance\n";
	List.list_all();
	cout << endl;
	List.insertion_sort_by_account();
	cout << "List is in increasing order of account number\n";
	List.list_all();
	cout << endl;
	cin.get();
	return 1;
}