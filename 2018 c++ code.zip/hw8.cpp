/***************************************
Austin Duda
I308
HW8
4/2//2018
****************************************/
#include <iostream>
#include <string>
using namespace std;

class BinaryNode
{
public:
	int account_number;
	string name;
	double balance;
	BinaryNode * left;
	BinaryNode * right;
public:
	BinaryNode(int account_number, string name, double balance);
};

BinaryNode::BinaryNode(int account_number, string name, double balance)
{
	this->account_number = account_number;
	this->name = name;
	this->balance = balance;
	this->left = NULL;
	this->right = NULL;
}

class Account_BST
{
private:
	BinaryNode * root;

public:
	Account_BST();
	void insert(int account_number, string name, double balance);
	void remove(int account_number);
	bool search(int account_number);
	void list_all();

	void insert_to_subtree(int account_number, string name, double balance, BinaryNode * & sub_tree_node);
	void remove_from_subtree(int account_number, BinaryNode * & sub_tree_node);
	BinaryNode * findMin(BinaryNode * t);
	BinaryNode * findMax(BinaryNode * t);
	bool search_subtree(BinaryNode * t, int account_number);

	void list_subtree(BinaryNode * t);
};

Account_BST::Account_BST()
{
	root = NULL;
}

void Account_BST::insert(int act, string name, double balance)
{
	insert_to_subtree(act, name, balance, root);
}

void Account_BST::remove(int act)
{
	remove_from_subtree(act, root);
}

bool Account_BST::search(int act)
{
	return search_subtree(root, act);
}

void Account_BST::list_all()
{
	list_subtree(root);
}

void Account_BST::insert_to_subtree(int act, string name, double balance, BinaryNode * & t)
{

	if (t == NULL)
	{
		t = new BinaryNode(act, name, balance);
	}
	else if (act < t->account_number)
	{
		insert_to_subtree(act, name, balance, t->left);

	}
	else if (act > t->account_number)
	{
		insert_to_subtree(act, name, balance, t->right);

	}
	else
		;
}

void Account_BST::remove_from_subtree(int act, BinaryNode * & t)
{
	if (t == NULL)
	{
		return;
	}
	else if (act < t->account_number)
	{
		remove_from_subtree(act, t->left);

	}
	else if (act > t->account_number)
	{
		remove_from_subtree(act, t->right);

	}
	else // found the node to remove
	{
		if (t->left != NULL && t->right != NULL) // two children
		{
			t->account_number = findMin(t->right)->account_number;
			remove_from_subtree(t->account_number, t->right);
		}
		else if (t->left != NULL) // one child
		{
			BinaryNode * oldNode = t;
			t = t->left;
			delete oldNode;
		}
		else if (t->right != NULL) // one child
		{
			BinaryNode * oldNode = t;
			t = t->right;
			delete oldNode;
		}
		else // no child
		{
			BinaryNode * oldNode = t;
			t = NULL;
			delete oldNode;
		}
	}
}

BinaryNode * Account_BST::findMin(BinaryNode * t)
{
	if (t == NULL) return NULL;
	else
	{
		if (t->left == NULL) return t;
		else
			return findMin(t->left);
	}
}

BinaryNode * Account_BST::findMax(BinaryNode * t)
{
	if (t == NULL) return NULL;
	else
	{
		if (t->right == NULL) return t;
		else
			return findMax(t->right);
	}
}

bool Account_BST::search_subtree(BinaryNode * t, int act)
{
	if (t == NULL)
		return false;
	else if (act < t->account_number)
		return search_subtree(t->left, act);
	else if (act > t->account_number)
		return search_subtree(t->right, act);
	else
		return true;
}

void Account_BST::list_subtree(BinaryNode * t)
{
	if (t == NULL) return;
	list_subtree(t->left);
	cout << t->account_number << "\t" << t->name << "\t" << t->balance << endl;
	list_subtree(t->right);
}

int main()
{
	Account_BST bst;
	bst.insert(1, "Henry Smith", 99.99);
	bst.insert(22, "Mudge Doug", 55.05);
	bst.insert(3, "Biscuit Nancy", 100);
	bst.insert(11, "Louise Buick", 33);
	bst.insert(32, "Merlinda Shuez", 9999);
	bst.insert(13, "Unknown Unknown", 2000);
	bst.remove(1);
	bst.insert(2, "Joe Mess", 20);
	bst.remove(11);
	bst.list_all();

	return 1;
}

/*
// After successfully implemented. You program should show the following result:
2       Joe Mess        20
3       Biscuit Nancy   100
13      Unknown Unknown 2000
22      Mudge Doug      55.05
32      Merlinda Shuez  9999
*/


