/*
Austin Duda
Info-308
Homework 7 list
Feburary 26th 2018
*/
#include <iostream>
#include <string>
using namespace std;

class node
{
public:
	int account_number;
	string name;
	double balance;
	node * next;
public:
	node(int v, string n, double b);
};

node::node(int v, string n, double b)
{
	this->account_number = v;
	this->name = n;
	this->balance = b;
	this->next = NULL;
}

class Account_Queue
{
private:
	node * qFront;
	node * qRear;

public:
	Account_Queue();
	~Account_Queue();
	bool isEmpty();
	void enqueue(node * n);
	node * dequeue();
};

Account_Queue::Account_Queue()
{
	qFront = NULL;
	qRear = NULL;
}

Account_Queue::~Account_Queue()
{
	node * temp = qFront;
	while (qFront != NULL)
	{
		qFront = qFront->next;
		delete temp;
		temp = qFront;
	}
}

bool Account_Queue::isEmpty()
{
	if (qFront == NULL) return true;
	else return false;
}

void Account_Queue::enqueue(node * n)
{
	// your code goes here
	// insert node n to the back (rear) of the queue
	node * b = new node(*n);
	if (isEmpty() == true)
	{
		qFront = qRear = b;
	}
	else
	{
		qRear->next = b;
		qRear = b;
	}
}




node * Account_Queue::dequeue()
{
	if (isEmpty() == false)
	{
		// your code goes here.
		// remove(and return) the node in front of the queue.
		// Note: because you are going to return this node, you do not need to deallocate space and this
		// is different from the interger queue example given in class.
	
		node*ttm = qFront;
		qFront = qFront->next;
		if (qFront == NULL)
		{
			qRear = NULL;
		}
		return ttm;
		delete ttm;

	}
	else return NULL;
}




int main()
{
	Account_Queue inque;
	node * n1 = new node(2002, "Janet Smith", 100.99);
	node * n2 = new node(1001, "Alex Bush", 99.88);
	node * n3 = new node(3003, "John Rosa", 5.55);

	inque.enqueue(n1);
	inque.enqueue(n2);
	inque.enqueue(n3);

	node * t1 = inque.dequeue();
	while (t1 != NULL)
	{
		cout << t1->name << endl;
		delete t1;
		t1 = inque.dequeue();
	}
	cin.get();
	return 1;
}

/*
// after a successful implementation, running this program
// the following result will be shown
Janet Smith
Alex Bush
John Rosa
*/

